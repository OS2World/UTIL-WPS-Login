#define LOGIN_TITLE                 100
#define LOGIN_NAME                  101
#define LOGIN_PASSWORD              102
#define LOGIN_USERTEXT              103
#define LOGIN_PASSWORDTEXT          104
#define LOGIN_ICON                  105
#define ID_USERICON									106
#define LOGIN_SYSSHUTDOWN						107

